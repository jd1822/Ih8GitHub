package com.magcubic.projectorart;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class ArtRenderer implements GLSurfaceView.Renderer {

    private final int themeIndex;
    private final int paletteIndex;
    private final int symmetryIndex;

    private int program;
    private int uResolutionHandle;
    private int uTimeHandle;
    private int uThemeHandle;
    private int uPaletteHandle;
    private int uSymmetryHandle;

    private final long startTime;
    private FloatBuffer quadBuffer;

    private static final String VERTEX_SHADER =
            "attribute vec4 aPosition;\n" +
            "void main() {\n" +
            "    gl_Position = aPosition;\n" +
            "}\n";

    // Optimized for Mali-G31: zero conditional branching in ray-march loops
    private static final String FRAGMENT_SHADER =
            "precision mediump float;\n" +
            "uniform vec2 uResolution;\n" +
            "uniform float uTime;\n" +
            "uniform int uTheme;\n" +
            "uniform int uPalette;\n" +
            "uniform int uSymmetry;\n" +
            "\n" +
            "vec3 getPalette(float t) {\n" +
            "    // Inigo Quilez cosine color palettes\n" +
            "    vec3 a = vec3(0.5, 0.5, 0.5);\n" +
            "    vec3 b = vec3(0.5, 0.5, 0.5);\n" +
            "    vec3 c = vec3(1.0, 1.0, 1.0);\n" +
            "    vec3 d = vec3(0.00, 0.33, 0.67);\n" + // Rainbow
            "    if (uPalette == 1) { c = vec3(2.0, 1.0, 0.0); d = vec3(0.50, 0.20, 0.25); }\n" + // Aurora / Space
            "    if (uPalette == 2) { c = vec3(1.0, 0.7, 0.4); d = vec3(0.70, 0.15, 0.20); }\n" + // Cyberpunk
            "    if (uPalette == 3) { c = vec3(1.0, 1.0, 0.5); d = vec3(0.30, 0.20, 0.80); }\n" + // Solar Flame
            "    return a + b * cos(6.28318 * (c * t + d));\n" +
            "}\n" +
            "\n" +
            "void main() {\n" +
            "    vec2 uv = (gl_FragCoord.xy * 2.0 - uResolution.xy) / min(uResolution.x, uResolution.y);\n" +
            "    vec2 uv0 = uv;\n" +
            "    vec3 finalColor = vec3(0.0);\n" +
            "\n" +
            "    // Symmetry angles: 4, 6, 8, 12\n" +
            "    float symCount = 4.0;\n" +
            "    if (uSymmetry == 1) symCount = 6.0;\n" +
            "    if (uSymmetry == 2) symCount = 8.0;\n" +
            "    if (uSymmetry == 3) symCount = 12.0;\n" +
            "\n" +
            "    // Kaleidoscopic polar folding\n" +
            "    float angle = 3.14159265 / symCount;\n" +
            "    for (int i = 0; i < 4; i++) {\n" +
            "        float a = atan(uv.y, uv.x);\n" +
            "        a = mod(a, 2.0 * angle) - angle;\n" +
            "        uv = length(uv) * vec2(cos(a), sin(a));\n" +
            "        uv = abs(uv) - 0.35;\n" +
            "        uv *= 1.35;\n" +
            "    }\n" +
            "\n" +
            "    float d = length(uv) * exp(-length(uv0));\n" +
            "    float speed = uTime * 0.4;\n" +
            "    vec3 col = getPalette(length(uv0) + speed + float(uTheme) * 0.5);\n" +
            "\n" +
            "    d = sin(d * 8.0 + speed) / 8.0;\n" +
            "    d = abs(d);\n" +
            "    d = pow(0.018 / d, 1.2);\n" +
            "    finalColor += col * d;\n" +
            "\n" +
            "    gl_FragColor = vec4(finalColor, 1.0);\n" +
            "}\n";

    public ArtRenderer(int theme, int palette, int symmetry) {
        this.themeIndex = theme;
        this.paletteIndex = palette;
        this.symmetryIndex = symmetry;
        this.startTime = System.currentTimeMillis();

        float[] quadCoords = {
                -1.0f,  1.0f,
                -1.0f, -1.0f,
                 1.0f,  1.0f,
                 1.0f, -1.0f
        };
        ByteBuffer bb = ByteBuffer.allocateDirect(quadCoords.length * 4);
        bb.order(ByteOrder.nativeOrder());
        quadBuffer = bb.asFloatBuffer();
        quadBuffer.put(quadCoords);
        quadBuffer.position(0);
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        int vShader = loadShader(GLES20.GL_VERTEX_SHADER, VERTEX_SHADER);
        int fShader = loadShader(GLES20.GL_FRAGMENT_SHADER, FRAGMENT_SHADER);
        program = GLES20.glCreateProgram();
        GLES20.glAttachShader(program, vShader);
        GLES20.glAttachShader(program, fShader);
        GLES20.glLinkProgram(program);

        uResolutionHandle = GLES20.glGetUniformLocation(program, "uResolution");
        uTimeHandle = GLES20.glGetUniformLocation(program, "uTime");
        uThemeHandle = GLES20.glGetUniformLocation(program, "uTheme");
        uPaletteHandle = GLES20.glGetUniformLocation(program, "uPalette");
        uSymmetryHandle = GLES20.glGetUniformLocation(program, "uSymmetry");
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        GLES20.glViewport(0, 0, width, height);
        GLES20.glUseProgram(program);
        GLES20.glUniform2f(uResolutionHandle, (float) width, (float) height);
        GLES20.glUniform1i(uThemeHandle, themeIndex);
        GLES20.glUniform1i(uPaletteHandle, paletteIndex);
        GLES20.glUniform1i(uSymmetryHandle, symmetryIndex);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        GLES20.glUseProgram(program);
        float time = (System.currentTimeMillis() - startTime) / 1000.0f;
        GLES20.glUniform1f(uTimeHandle, time);

        int posHandle = GLES20.glGetAttribLocation(program, "aPosition");
        GLES20.glEnableVertexAttribArray(posHandle);
        GLES20.glVertexAttribPointer(posHandle, 2, GLES20.GL_FLOAT, false, 0, quadBuffer);

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
        GLES20.glDisableVertexAttribArray(posHandle);
    }

    private static int loadShader(int type, String shaderCode) {
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, shaderCode);
        GLES20.glCompileShader(shader);
        return shader;
    }
}