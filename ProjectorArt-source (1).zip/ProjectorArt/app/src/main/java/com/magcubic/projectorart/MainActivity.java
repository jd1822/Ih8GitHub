package com.magcubic.projectorart;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;
import java.util.Random;

public class MainActivity extends Activity {

    private Spinner spTheme, spPalette, spSymmetry;
    private CheckBox cbRandomTheme, cbRandomPalette, cbRandomSymmetry;
    private final Random random = new Random();

    private final String[] themes = {"Kaleidoscopic Core", "Liquid Aurora Dream", "Cyber Tunnel", "Quantum Nebulae"};
    private final String[] palettes = {"Vibrant Psychedelic", "Deep Space / Bioluminescent", "Electric Synthwave", "Solar Flame"};
    private final String[] symmetries = {"4-Fold Mirror", "6-Fold Hexagonal", "8-Fold Octagonal", "12-Fold Star"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spTheme = findViewById(R.id.spTheme);
        spPalette = findViewById(R.id.spPalette);
        spSymmetry = findViewById(R.id.spSymmetry);

        cbRandomTheme = findViewById(R.id.cbRandomTheme);
        cbRandomPalette = findViewById(R.id.cbRandomPalette);
        cbRandomSymmetry = findViewById(R.id.cbRandomSymmetry);

        spTheme.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, themes));
        spPalette.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, palettes));
        spSymmetry.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, symmetries));

        Button btnStart = findViewById(R.id.btnStart);
        btnStart.requestFocus(); // Auto-focus for TV/Projector remote D-Pad
        btnStart.setOnClickListener(v -> launchProjection());
    }

    private void launchProjection() {
        int themeIdx = cbRandomTheme.isChecked() ? random.nextInt(themes.length) : spTheme.getSelectedItemPosition();
        int paletteIdx = cbRandomPalette.isChecked() ? random.nextInt(palettes.length) : spPalette.getSelectedItemPosition();
        int symmetryIdx = cbRandomSymmetry.isChecked() ? random.nextInt(symmetries.length) : spSymmetry.getSelectedItemPosition();

        Intent intent = new Intent(this, ProjectionActivity.class);
        intent.putExtra("THEME_IDX", themeIdx);
        intent.putExtra("PALETTE_IDX", paletteIdx);
        intent.putExtra("SYMMETRY_IDX", symmetryIdx);
        startActivity(intent);
    }
}