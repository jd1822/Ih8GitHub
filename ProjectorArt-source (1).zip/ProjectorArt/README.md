# ProjectorArt

Android OpenGL ES 2.0 projector-art app reconstructed from the AI Studio code blocks.

## Open in Android Studio
Open this `ProjectorArt` directory as an existing Gradle project. The project uses Android Gradle Plugin 7.4.2, compileSdk 33, minSdk 21, and targetSdk 31.

## Important
`app/build.gradle` was reconstructed from the build script because it was not supplied as one of the individual downloaded blocks.
